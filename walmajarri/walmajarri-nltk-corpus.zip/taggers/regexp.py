# Regular expression tagger

# Allomorphs of morphemes beginning with rl
rl_allomorphs = '(' + '|'.join((
	'ly', 'l', 'rr', # rl->0 / lateral|vibrant _
	'rt', 'rnt', # rl->rt / apico-postalveolar _
	'pt', 'mt', 't', 'nt', # rl->t / bilabial|apico-alveolar _
	'j', 'nyj', 'kj', 'ngj', # rl->j / velar|lamino _
	'ng', # When the root has two syllables
	'rl', # Elsewhere
)) + ')'

# Allomorphs of -ku
ku_allomorphs = '(' + '|'.join((
	'awu', 'iwu', 'uwu', # ku->wu / vowel _
	'pku', 'mku', 'wku', 'tku', 'nku', 'lku', 'rku', 'yku', 'jku', 'kku', 'ngku', # elsewhere
)) + ')'

patterns = [
    ('.*yu$', 'DIS'), # Discourse, 'yes' Here because of the stupid quotes

    #('.*jirni$', 'N'), # Verb

	('.*warnti$', 'N'), # Nominal -DL (Dual)
	#('.*jarra$', 'N'), # Nominal -PLural

	# Nominal -PURP/DAT
	('.*purru$', 'N'), # -PURP only
	#('.*' + ku_allomorphs + '$', 'N'), # -PURP/DAT
	
	# Nominal -PR (Projected reason)
	('.*karrarla$', 'N'),
	('.*' + rl_allomorphs + 'amarra$', 'N'),
	
	# Nominal -ALLative
	('.*karti$', 'N'),
	('.*' + rl_allomorphs + 'urra$', 'N'),
	('.*' + rl_allomorphs + 'awu$', 'N'),
	
	('.*ngurni$', 'N'), # Nominal -ABLative
	('.*' + rl_allomorphs + 'alu$', 'N'), # Nominal -BYW (By way of)
	('.*wurra$', 'N'), # Nominal -CONSequent
	('.*karra$', 'N'), # Nominal -MANner

    #('.*yani$', 'V'), # Verb
    ('.*ni$', 'V'), # Verb
    #('.+((?<!ny)i|nya)$', 'V'), # Verb -PAST
    #('^(ng|rn|n|ny).+an$', 'V'), # Verb -REP
    ('.+any$', 'V'), # Verb -CUST

    ('^pa.*', 'AUX'), # Auxiliary
    ('^pila.*', 'AUX'),
    ('^ma.*', 'AUX'),
    ('^ngarta.*', 'AUX'),

	('.*' + rl_allomorphs + 'u$', 'N'), # Nominal -ERG
	('.*' + rl_allomorphs + 'a$', 'N'), # Nominal -LOC/ACC

    ('.*nya$', 'V'), # Verb
    #('.+ta$', 'V'), # Verb - IRR + NPAST
]
