# NLTK patches for the Walmajarri corpus

import re

# zipimport NLTK if needed
try:
	import nltk
except ImportError:
	import sys
	sys.path.insert(0, 'nltk.zip')
	import nltk

# Discard comments
sent_tokenizer = nltk.tokenize.regexp.RegexpTokenizer(r'([.,?](")?)|(([.,])?\s*(#.*)?\n)', gaps=True, flags=re.M)

# Walmajarri tag simplifier
tag_pattern = re.compile('\w+(-AUX)?')
def simplify_walmajarri_tag(tag):
	return tag_pattern.match(tag).group(0)

# Subclass TaggedCorpusReader to allow better access to the tags
class WalmajarriCorpusReader(nltk.corpus.TaggedCorpusReader):
	def tagged_sents(self, fileids=None, simplify_tags=None):
		# If given a simplify_tags option fall back
		if simplify_tags is not None:
			return nltk.corpus.TaggedCorpusReader.tagged_sents(self, fileids=fileids, simplify_tags=simplify_tags)
		
		# Return both simplified and full tags
		full = self.tagged_sents(fileids=fileids, simplify_tags=False)
		sentences = []
		for sentID in range(len(full)):
			sentence = []
			for word in range(len(full[sentID])):
				sentence.append((full[sentID][word][0], simplify_walmajarri_tag(full[sentID][word][1]), full[sentID][word][1]))
			sentences.append(sentence)
		return sentences

# A class for Walmajarri verbs, based on the wordlist reader, but which allows for comments
class WalmajarriVerbsReader(nltk.corpus.WordListCorpusReader):
	def words(self, fileids=None):
		return sent_tokenizer.tokenize(self.raw(fileids))

# Add the Walmajarri corpora
nltk.corpus.walmajarri = WalmajarriCorpusReader('data', '.*\.tagged\.txt', sent_tokenizer=sent_tokenizer, tag_mapping_function=simplify_walmajarri_tag)
nltk.corpus.walmajarri_verbs = WalmajarriVerbsReader('data', '.*\.verbs\.txt')
