#!/usr/bin/env python
# Walmajarri Clause initial position data

import re
import texttable

# Run our NLTK patches
import patch
import nltk
from nltk.corpus import walmajarri, walmajarri_verbs

from taggers.classifier import irr_features

walmajarri_tagged_sents = walmajarri.tagged_sents()

# Prepare the verb classifier
tagged_verbs = ([(word, 'IRR') for word in walmajarri_verbs.words('irrealis.verbs.txt')] + [(word, 'REAL') for word in walmajarri_verbs.words('realis.verbs.txt')])
verbfeatures = [(irr_features(n), g) for (n,g) in tagged_verbs]
verbclassifier = nltk.DecisionTreeClassifier.train(verbfeatures)

# Sentences I've already analysed
analysed_sents = open('processed-clauses.txt').read().splitlines()

def printsent(sent):
	return ' '.join(['%s/%s' % (word[0], word[2]) for word in sent])

# Analyse!
totalclauses = len(walmajarri_tagged_sents)
print '\nTotal clauses: ', totalclauses

# Run through each sentence and classify
MR1_pattern = re.compile('[mp]')
clauses = {
	'MR1': {'RTS': [], 'ITS': [], 'Vs': [], 'No V': [], 'Count': 0},
	'MR2': {'RTS': [], 'ITS': [], 'Vs': [], 'No V': [], 'Count': 0},
	'MR3': {'RTS': [], 'ITS': [], 'Vs': [], 'No V': [], 'Count': 0},
	'NOM': {'RTS': [], 'ITS': [], 'Vs': [], 'No V': [], 'Count': 0},
	'AUXs': {'RTS': [], 'ITS': [], 'Vs': [], 'No V': [], 'Count': 0},
	'No AUX': {'RTS': [], 'ITS': [], 'Vs': [], 'No V': [], 'Count': 0},
	'Count': {'RTS': 0, 'ITS': 0, 'Vs': 0, 'No V': 0},
}
for sent in walmajarri_tagged_sents:
	transposed = zip(*sent)
	plainsent = printsent(sent)
	
	# More than one AUX
	if transposed[1].count('AUX') > 1:
		aux = 'AUXs'
		print aux, plainsent
	
	# MR1/MR2
	elif 'AUX' in transposed[1]:
		if MR1_pattern.match(transposed[0][ transposed[1].index('AUX') ]):
			aux = 'MR1'
		else:
			aux = 'MR2'
			if plainsent not in analysed_sents:
				print aux, plainsent
			
	# No AUX
	else:
		if 'V-AUX' in transposed[2]:
			aux = 'MR3'
		elif 'N-AUX' in transposed[2]:
			aux = 'NOM'
		else:
			aux = 'No AUX'
		
		if aux is not 'No AUX' and plainsent not in analysed_sents:
			print aux, plainsent
	
	# Replace V-AUX with V
	transposed[1] = [(tag == 'V-AUX' and 'V' or tag) for tag in transposed[1]]
	
	# Type of verb - none!
	if 'V' not in transposed[1]:
		verb = 'No V'
	
	# Multiple verbs
	# Account for NOMLSR-PAST -> count as having one verb, classified by the other
	elif transposed[1].count('V') > 1:
		verb = 'Vs'
		if plainsent not in analysed_sents and aux in ('MR1', 'No AUX'):
			print verb, plainsent
		
	else:
		if verbclassifier.classify(irr_features(transposed[0][ transposed[1].index('V') ])) == 'IRR':
			verb = 'ITS'
			if plainsent not in analysed_sents and aux in ('MR1', 'No AUX'):
				print verb, plainsent
		else:
			verb = 'RTS'
	
	# Negatives
	if plainsent not in analysed_sents and ('gajirta' in plainsent or 'kayan' in plainsent or 'Kayan' in plainsent):
		print 'NEG', plainsent
	
	clauses[aux][verb].append(sent)
	clauses[aux]['Count'] += 1
	clauses['Count'][verb] += 1

def row_counts(title, row):
	return (title,
		len(row['RTS']),
		len(row['ITS']),
		len(row['Vs']),
		len(row['No V']),
		'%.2f' % (float(row['Count']) / totalclauses * 100),
	)

table = texttable.Texttable()
table.add_rows((
	(
		'',
		'RTS',
		'ITS',
		'Multiple Vs',
		'No V',
		'%',
	),
	row_counts('MR1 pa', clauses['MR1']),
	row_counts('MR2 nga', clauses['MR2']),
	row_counts('MR3 V=AUX', clauses['MR3']),
	row_counts('N=AUX', clauses['NOM'])
))
if clauses['AUXs']['Count'] > 0:
	table.add_row(row_counts('Multiple AUXs', clauses['AUXs']))
table.add_rows((
	row_counts('No AUX', clauses['No AUX']),
	(
		'%',
		'%.2f' % (float(clauses['Count']['RTS']) / totalclauses * 100),
		'%.2f' % (float(clauses['Count']['ITS']) / totalclauses * 100),
		'%.2f' % (float(clauses['Count']['Vs']) / totalclauses * 100),
		'%.2f' % (float(clauses['Count']['No V']) / totalclauses * 100),
		'',
	),
), False)
print table.draw()
