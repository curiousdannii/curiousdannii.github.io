# Classifier tagger

import re

# Nominal roots
nom_roots = '^(' + '|'.join((
	'mana(?!n)', # tree, thing
	'ngana', # who/what
	'nyana', # that
	'wirriwirri', # windmill
)) + ')'

# Nominal derivations
nom_derivs = '(' + '|'.join(( # !!!
	'j[iu]l[ai]ny', # like
	'warlany', # another
)) + ')'
all_nom_derivs = nom_derivs[:-1] + '|u(' + '|'.join((
	'jangka', # originating from
	'juwal', # habitual
	#'j[iu]l[ai]ny', # like
	'karra', # manner
	'marta', # who who is
	'ngurni', # from
	'purru', # purpose
	#'warlany', # another
)) + '))'

# Simple stems pattern
verblist = (
	'jakarn', # start
	'jawuma', # swim
	'j[iu]npung', # single out
	'jula', # tell
	'jupul', # chase
	'jurum', # wait
	'kang', # take
	'kanyji', # dance/tread
	'karlarn', # dig
	'karri', # stand
	'karrpi', # tie up
	'kirra', # sit
	'kurnak', # turn around
	'kurrkant|waapiny', # finish
	'lan[aktu]', # spear
	'luwa', # hit
	'marn(?!in|pa)', # spoke, but not woman, close
	'marta', # have
	'ngalk', # will eat
	'ngarn[iu]', # eat
	'ngu(niny|ja)', # exist
	'nyak', # see
	'parayan', # climb
	'parlipu', # find
	'pinak', # hear
	'pirri(?!lka)', # catch up
	'purr[au][kl]', # bubble/boil/fan
	'rir?i[mp]ar?n', # sway/shake
	'tarrp', # grasp/leave
	'tartayan', # set
	'tikirr', # return etc
	'turtap', # rise
	'waan', # follow
	'wanti', # fall
	'warkam', # work
	'warnt(?!arr)', # get, but not road
	'wurna', # go
	'yan(an)?(i|ku|ta|u)', # go
	'yinp', # sing
	'yipa', # scrape/send
	'yukarn', # lie down
)
simple_verbs = '^(' + '|'.join(verblist) + ')'
roots = '|'.join((
	'jarri(nya)?', # INCHO
	'kuji(rn)?', # CAUS
	'laparn', # run
	#'u(karra)?kang', # NOMLSR-MAN-carry # !!!
))

# Coverbs
coverbs = '^(' + '|'.join((
	'jawu', # swim
	'ruwa', # walkabout/hunt
	'tikirr', # return
	'wirtiwirti', # move
	'wurna', # go
	'yarr', # just
	'yap', # out of sight
)) + ')([kw]u|nga|karra)?$'

# Auxiliary pattern
object_number = '(ja|panya|ta|pinya|ji|ngu|(?<=rli|nan|rna)pangu|rla|pilangu|nyirrangu|nyanangu|nya(?!nu))'
subject_number = '(pila|lu?)'
auxiliary = re.compile('''^
	(pa(?!m|n|rn|ny|ng)|ma(?=m|n|rn|ny|ng)|pila # MR1
	|nga)? # MR2
	(rta)? # Dubitative aspect
	(rli|jarra|jarrarna|rlipa|rna|n)? # Subject person
	(rli|jarra|rlipa|rna|ny)? # Object person
	''' + object_number + '''? # Object number
	''' + subject_number + '''? # Subject number
	(rla|nyanta)? # ACC/DAT marker
	(nyanu|n)? # REFL
$''', re.VERBOSE)
number_swap = re.compile(subject_number + object_number)
incorrect_MR1 = re.compile('pa(?=m|n|rn|ny|ng)|ma(?!m|n|rn|ny|ng)')

def test_auxiliary(word):
	# Test for swapped number morphemes
	old_word = word
	word = number_swap.sub(r'\2\1', word)

	# Correct the MR1 allomorph too if needed
	if number_swap.search(old_word) and incorrect_MR1.match(word):
		if word[0] == 'p':
			word = 'm' + word[1:]
		elif word[0] == 'm':
			word = 'p' + word[1:]

	return auxiliary.match(word) != None

# Connectors
connectors = '^(' + '|'.join((
	'an$', # and
	'kitangarni', # until
	'kula', # contrary to fact
	'minya(?![rw])', # when
	'nyanartijangka',
	'wali(rni)?$', # alright, that's it
	'yangkala', # then, but, as a result
	'yarnta', # again, and, also
)) + ')'

# Particles
particles = '^(' + '|'.join((
	'jarti',
	'kunyun',
	'pa!', # let's go
	'ya(rr)?((pa)?rni)?$',
	'yu$',
)) + ')'

# Walmajarri features
def walmajarri_features(tokens, index, history):
	# Strip off clitics and initial quotes
	full_word = re.match('^"?(.+)', tokens[index].lower()).group(1)
	word_with_rni = re.match('^(.+?)((?<!r)((?<![aiu])pa)?la|jal)?$', full_word).group(1)
	word = re.match('^(.+?)(((?<![aiu])pa)?rni)?$', word_with_rni).group(1)
	
	features = {
		
		'1P': index == 1,
		
		# Nominal features
		'nom-roots': re.search(nom_roots, word_with_rni) != None,
		'nom-derivations': re.search(nom_derivs, word_with_rni) != None,
		
		# Verb stems
		'verb-stems': re.search(simple_verbs, word_with_rni) != None,
		'verb-roots': re.search(roots, word_with_rni) != None,
		
		# Verb suffixes
		'verb-REP-PAST/PRES': re.search('an(a|i)$', word) != None,
		'verb-PAST': re.search('nya$', word) != None,
		'verb-CUST': re.search('any$', word) != None,
		#'verb-REP-IRR-PAST?': re.search('anta(rla)?$', word) != None,
		
		# Connector features
		'CON': re.search(connectors, full_word) != None,
		
		# Particles
		'PART': re.search(particles, word) != None,
		
		# Auxiliary
		'AUX': test_auxiliary(full_word),
		
		# Coverbs
		'coverb': re.search(coverbs, word) != None,
		
	}

	return features

# Features for distinguishing IRR verbs
def irr_features(word):
	# Strip off clitics and initial quotes
	full_word = re.match('^"?(.+)', word.lower()).group(1)
	word = re.match('^(.+?)((?<!r)((?<![aiu])pa)?la|wurti)?$', full_word).group(1)
	
	# Hack for nyaka etc
	if word[:3] == 'nya':
		word = 'nyang' + word[3:]
	
	features =  {
		'PAST': re.search('(an)?((?<!ny)(?<!jarr)i|nya)$', word) != None,
		'REP-PRES': re.search('ana$', word) != None,
		'REAL-COMP': re.search('(?<!rla)(ngurra|nyirra)$', word) != None,
		'CUST': re.search('any$', word) != None,
		'FUT': re.search('[kw]u$', word) != None,
		'IRR-PAST': re.search('rla(ngurra|nyirra)?$', word) != None,
		'REP-IRR': re.search('anta$', word) != None,
		'IRR': re.search('(rra|yja|gka|nta)$', word) != None,
		'IRR-0': re.search('((?<!an|rn)i|(?<!l|n|y)(?<!^nguj)a)$', word) != None,
		'INF': re.search('u(ngurla|rla)?$', word) != None,
	}
	
	return features
