# A Walmajarri concordance

import re
import threading

import nltk
from ConcordanceSearchModel import ConcordanceSearchModel

WORD_OR_TAG = '[^/ ]+'
BOUNDARY = r'\b'

SEARCH_TERMINATED_EVENT = '<<ST_EVENT>>'
SEARCH_ERROR_EVENT = '<<SE_EVENT>>'

default_options = {
	'freq': True, # Output a frequency distribution of matching sentences
	'POS_only': False, # Output only the POS tags
}

word_and_tag = re.compile(BOUNDARY + '(' + WORD_OR_TAG + ')/(' + WORD_OR_TAG + ')' + BOUNDARY)

class WalmajarriConcordance(ConcordanceSearchModel):
	'A Walmajarri concordance'

	def __init__(self, opts):
		# Run the original constructor and save the options
		ConcordanceSearchModel.__init__(self)
		self.options = dict(default_options, **opts)
		
	class SearchCorpus(threading.Thread):
		def __init__(self, model, page, count):
			self.model, self.count, self.page = model, count, page
			threading.Thread.__init__(self)
			self.options = self.model.options

		def run(self):
			terms = self.processed_query()
			sent_pos, i, sent_count, matched = [], 0, 0, 0
			
			# Make a frequency distribution object if required
			if self.options['freq']:
				freq = nltk.FreqDist()
			
			for sent in self.model.tagged_sents[self.model.last_sent_searched:]:
				m = True
				try:
					# Search for the terms in any order (Note, does not handle repeated terms)
					for term in terms:
						if not term.search(sent):
							m = False
							break
							
				except re.error:
					self.model.reset_results()
					self.model.notify_listeners(SEARCH_ERROR_EVENT)
					return
				if m:
					#print sent
					matched += 1
					
					# Output only the POS tags?
					if self.options['POS_only']:
						sent = word_and_tag.sub(r'\2/\2', sent)

					# Increment the freq distribution for this sentence
					if self.options['freq']:
						freq.inc(sent)

					# Append the sentence directly
					else:
						if self.options['POS_only']:
							sent_pos.append((sent, 0, len(sent)))
						else:
							sent_pos.append((sent, m.start(), m.end()))

					i += 1
					if i > self.count:
						self.model.last_sent_searched += sent_count - 1
						break
				sent_count += 1

			# Format the frequency distribution for outputting
			if self.options['freq']:
				sent_pos = [('%s/FREQ %s' % (f, s), 0, len(s) + 8) for s, f in freq.items()]
				

			# Add the number of sentences found
			sent_pos.insert(0, ('%d/%d-TOTAL' % (matched, len(self.model.tagged_sents)), 0, 20))

			if (self.count >= len(sent_pos)):
				self.model.last_sent_searched += sent_count - 1
				self.model.last_page = self.page
				self.model.set_results(self.page, sent_pos)
			else:
				self.model.set_results(self.page, sent_pos[:-1])
			self.model.notify_listeners(SEARCH_TERMINATED_EVENT)

		def processed_query(self):
			'''Process a search query, returning a list of regex objects'''
			# The initial context, is the top list of regexs
			top = []
			context = top
			
			# Tokenise the search terms
			query = self.model.query
			tokens = nltk.word_tokenize(query.replace("'", '"'))
			#tokens = self.model.query.split()

			# Go through the search terms
			for term in tokens:
				# I'm not sure what purpose this serves
				#term = re.sub(r'\.', r'[^/ ]', term)
				
				# Search phrase
				if term == '"':
					if context is top:
						# Start a new context
						phrase = []
						top.append(phrase)
						context = phrase
					else:
						# Return to the top context
						context = top

				# Boundary matches
				elif term in ('^', '$'):
					context.append(term)

				else:
					# As Walmajarri words won't be POS tags, we can search case insensitively
					context.append(BOUNDARY + '(' + WORD_OR_TAG +'/)?[^/ ]*' + term + '[^/ ]*(/' + WORD_OR_TAG + ')?' + BOUNDARY)
			
			# Join phrase terms together
			terms = [term for term in top if isinstance(term, str)]
			phrases = [' '.join(phrase) for phrase in top if isinstance(phrase, list)]
			terms.extend(phrases)
			
			# Compile the regexs
			terms = [term.replace('^ ', '^').replace(' $', '$') for term in terms]
			terms = [re.compile(term, re.I) for term in terms]

			# Return the list of regexs
			return terms
