Walmajarri NLTK corpus
======================

By Dannii Willis
Copyright 2009-2012
BSD Licenced

This is a very rough NLTK corpus for Walmajarri, which I used when working on my thesis. It has a multi-layer classification tagger, and can be used to perform some simple sentence analysis. test-taggers.py and clause-stats.py demonstrate what it can do.

I have included two tagged texts which can be downloaded freely from http://www.ausil.org.au. The more texts you use to train the tagger the better its results will be, however other texts can probably not be distributed freely.