# Ambiguity fixing tagger

import re

import nltk
from nltk.tag.sequential import SequentialBackoffTagger

class AmbigTagger(SequentialBackoffTagger):
	'''A tagger that attempts to fix ambiguous words by comparing
	the context after the rest of the sentence has been tagged'''
	
	def __init__(self, backoff=None):
		# This class doesn't provide it's own tagger
		if backoff is None:
			self._taggers = []
		else:
			self._taggers = backoff._taggers
			
			# Add the classifier of the backoff tagger
			if hasattr(backoff, 'classifier'):
				self.classifier = backoff.classifier
	
	def tag(self, tokens):
		#tags = SequentialBackoffTagger.tag(self, tokens)
		# Taken from sequetial.py
		# docs inherited from TaggerI
		tags = []
		for i in range(len(tokens)):
			tags.append(self.tag_one(tokens, i, tags))
			
			# Fix ambiguous connectors
			# Connector must be in the list, and not in first, second or last position
			if re.search(ambig_cons, tokens[i].lower()) != None and 2 < i < (len(tokens) - 1):
				tags[i] = 'N'
		
		# Find sentences with two AUXs
		if tags.count('AUX') > 1:
			for i in range(len(tokens)):
				if re.search(ambig_noms, tokens[i].lower()) != None: tags[i] = 'N'
				if re.search(ambig_verbs, tokens[i].lower()) != None: tags[i] = 'V'
		
		return zip(tokens, tags)

ambig_noms = '^(' + '|'.join((
	'ngaji', # I PRO
	'paja$', # many
)) + ')'
ambig_verbs = '^(' + '|'.join((
	'manyj', # speak, burn
	'nganyjarla', # eat
	'paja(rra)?rla', # cut/bite
	'parlipinya', # found
)) + ')'
ambig_cons = '^(' + '|'.join((
	'minya', # this one
)) + ')'
