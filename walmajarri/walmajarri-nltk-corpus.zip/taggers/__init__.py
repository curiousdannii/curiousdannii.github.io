# Walmajarri taggers

import nltk

import regexp
import root
import classifier
import ambig

# Build a tagger chain
def build_tagger_chain(taggers):
	chain = None

	# Go through the list of taggers
	for (tagger, options) in taggers:
		# Add the backoff tagger
		options['backoff'] = chain

		if tagger == 'regexp':
			chain = nltk.RegexpTagger(regexp.patterns, **options)
			
		elif tagger == 'root':
			chain = root.RootTagger(**options)
			
		elif tagger == 'classifier':
			chain = nltk.tag.sequential.ClassifierBasedTagger(feature_detector=classifier.walmajarri_features, **options)
			
		elif tagger == 'ambig':
			chain = ambig.AmbigTagger(**options)
			
		else:
			chain = nltk.DefaultTagger(tagger)
	
	return chain

#import cPickle as pickle
#tagger1 = build_tagger_chain([('classifier', {
#		'classifier_builder' : nltk.classify.MaxentClassifier.train,
#		'train': walmajarri_tagged_sents,
#	})])
#print pickle.dumps(tagger1)
