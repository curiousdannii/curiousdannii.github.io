# Root (lookup) tagger

import re
import sys

import nltk
from nltk.tag.sequential import SequentialBackoffTagger

# Root tagger class
class RootTagger(SequentialBackoffTagger):
    '''A root (lookup) tagger. This is like a UnigramTagger, but with the
    advantage that suffixes can be ignored.'''
    def __init__(self, files=[], backoff=None):
        SequentialBackoffTagger.__init__(self, backoff)
        
        # Add the classifier of the backoff tagger
        if hasattr(backoff, 'classifier'):
	    	self.classifier = backoff.classifier

    def choose_tag(self, tokens, index, history):
        word = re.match('^"?(.+)', tokens[index].lower()).group(1)
        for tag, roots in all_roots:
            for root in roots:
                if word[:len(root)] == root:
                    return tag
        return None

# List of roots
all_roots = (
	('N', (
		'ngarlijarra', # pro ???
	)),
	('X', (
		'murtaylmurtayikarra',
		'nyapartujarrinya',
		'payamkujirnupurru',
	)),
)
