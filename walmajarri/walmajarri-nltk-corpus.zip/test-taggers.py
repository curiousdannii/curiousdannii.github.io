#!/usr/bin/env python2.6
# Walmajarri Parts of speech tagger

import random

# Run our NLTK patches
import patch
import nltk

# Import our taggers
import taggers
from taggers.classifier import irr_features

# Test data
from nltk.corpus import walmajarri, walmajarri_verbs
walmajarri_tagged_sents = walmajarri.tagged_sents(simplify_tags=True)
walmajarri_tagged_words = walmajarri.tagged_words(simplify_tags=True)

verbs = walmajarri_verbs.words('irrealis.verbs.txt') + walmajarri_verbs.words('realis.verbs.txt')
tagged_verbs = ([(word, 'IRR') for word in walmajarri_verbs.words('irrealis.verbs.txt')] + [(word, 'REAL') for word in walmajarri_verbs.words('realis.verbs.txt')])

# Randomised train and test data
walmajarri_random_sents = list(walmajarri_tagged_sents)
#random.seed(56)
random.shuffle(walmajarri_random_sents)
train_fraction = int(len(walmajarri_random_sents) * 0.8)
walmajarri_train = walmajarri_random_sents[:train_fraction]
walmajarri_test = walmajarri_random_sents[train_fraction:]

# Confusion matrix generator
def print_matrix(tagger):
    test_tags = [tag for sent in walmajarri.sents()
                     for (word, tag) in tagger.tag(sent)]
    gold_tags = [tag for (word, tag) in walmajarri_tagged_words]
    print nltk.ConfusionMatrix(gold_tags, test_tags)

def print_verb_matrix(classifier):
	gold_verbs = [tag for (word, tag) in tagged_verbs]
	test_verbs = [classifier.classify(irr_features(word)) for word in verbs]
	print nltk.ConfusionMatrix(gold_verbs, test_verbs)

# Errors lister
def print_errors(tagger, n=0, tags=None):
	if tags == None: tags = ['AUX', 'CON', 'CV', 'DIS', 'N', 'PART', 'V', 'X']
	errors = []	
	gold = walmajarri_tagged_words
	test = [tagger.tag(sent) for sent in walmajarri.sents()]
	test = [item for sublist in test for item in sublist]
	for i in range(len(gold)):
		if gold[i] != test[i] and gold[i][1] in tags:
			errors.append((gold[i][0], gold[i][1], test[i][1]))
	errors = sorted(errors, key=lambda word: word[0])[:n]
	for error in errors:
		print '%s/%s Guess: %s' % (error[0], error[1], error[2])

def print_verb_errors(classifier):
	errors = []
	gold = tagged_verbs
	test = [classifier.classify(irr_features(word)) for word in verbs]
	for i in range(len(gold)):
		if gold[i][1] != test[i]:
			errors.append((gold[i][0], gold[i][1], test[i]))
	errors = sorted(errors, key=lambda word: word[0])
	for error in errors:
		print '%s/%s Guess: %s' % (error[0], error[1], error[2])
		#print irr_features(error[0])

# Classifier tester
def test_classifier(title, builder=nltk.DecisionTreeClassifier, root=0, ambig=0, matrix=0, errors=None, info=0):
	chain = [('classifier', {
		'classifier_builder' : builder.train,
		'train': walmajarri_tagged_sents,
	})]
	if root:
		chain.append(('root', {}))
	if ambig:
		chain.append(('ambig', {}))
	tagger = taggers.build_tagger_chain(chain)
	print 'Classifier (' + title + '):', tagger.evaluate(walmajarri_tagged_sents)
	if matrix:
		print_matrix(tagger)
	if info and hasattr(tagger, 'classifier'):
		classifier = tagger.classifier()
		if isinstance(classifier, nltk.DecisionTreeClassifier):
			print classifier.pseudocode(depth=20)
		elif isinstance(classifier, nltk.NaiveBayesClassifier):
			classifier.show_most_informative_features(20)
	print_errors(tagger, 40, errors)

# Some initial stats
print '\nTotal sentences: ', len(walmajarri_tagged_sents)
print 'Total words: ', len(walmajarri_tagged_words)

# The default tagger
#default_noun_tagger = taggers.build_tagger_chain((('N', {}),))
#print 'Default tagger:', default_noun_tagger.evaluate(walmajarri_tagged_sents)

#test_classifier('maxent', root=1, builder=nltk.classify.MaxentClassifier, matrix=0, info=1)
#test_classifier('bayes+root', root=1, builder=nltk.NaiveBayesClassifier, matrix=0, errors=[], info=0)
test_classifier('tree+root+ambig', root=1, ambig=1, matrix=1, errors=None, info=1)

# IRR classifier
if 1 is 1:
	verbfeatures = [(irr_features(n), g) for (n,g) in tagged_verbs]
	verbclassifier = nltk.DecisionTreeClassifier.train(verbfeatures)
	print '\nIRR classifier:', nltk.classify.accuracy(verbclassifier, verbfeatures)
	print_verb_matrix(verbclassifier)
	print verbclassifier.pseudocode(depth=20)
	print_verb_errors(verbclassifier)
